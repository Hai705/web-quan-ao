<template>
  <dashboard-layout>
    <Nuxt />
  </dashboard-layout>
</template>

<script>
import DashboardLayout from '@/components/admin/dashboard/Layout.vue'
export default {
  components: { DashboardLayout }
}
</script>
